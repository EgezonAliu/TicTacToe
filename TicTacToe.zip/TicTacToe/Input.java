import java.util.Scanner;
public class Input {

    private Scanner input ;
    private Tabel tabel;
    
     public Input(Tabel tabel) {
        this.tabel = tabel;
        input = new Scanner(System.in);
    }
     public int [] cordinates() {
        int[] result = new int[2];

        int xPosition = -1;
        int yPosition = -1;
        boolean validInput;
        do {

            xPosition = input.nextInt();
            xPosition--;

            yPosition = input.nextInt();
            yPosition--;

            input.nextLine();
            validInput = xPosition >= 0 && xPosition <= Tabel.ROWS && yPosition >= 0 && yPosition <= Tabel.COLUMN;
            if (validInput) {
                result[0] = xPosition ;
                result[1] = yPosition ;
            }
            System.out.println(validInput);
        } while (!validInput);
        return result ;
    }
    public String choosePlayer() {
        String player ;
        do {
            System.out.print("First player choose : ");
            player = input.nextLine();
            if (player.length() > 0) {
                player = player.substring(0, 1).toUpperCase();
            }
            if (!player.equals("X") && !player.equals("O")) {
                System.out.println("Player must be X or O !!");
            }
        } while (!player.equals("X") && !player.equals("O"));
        return player ;
    }
    
     public boolean playAgain() {
        boolean process  = true;
        String line;
        do {
            System.out.print("Do you want to play again (Y/N)?");
            line = input.nextLine();
            if (line.length() > 0) {
                line = line.substring(0, 1);
                if (line.equalsIgnoreCase("Y") || line.equalsIgnoreCase("N")) {
                    process = false;
                } else {
                    System.out.println("Wrong input , please type Y or N!!");
                }
            }
            
        } while (process);
        return line.equalsIgnoreCase("Y");
    }

    public void read(String player) {
        System.out.print("'" + player + "',type position where do you want to play: ");
        int[] cordinate = cordinates();
        int x = cordinate[0];
        int y = cordinate[1];
        try {
            tabel.setValue(x, y, player);
            tabel.saveActualRowColumn(x, y) ;
        } catch (TicTacToeException ex) {
            // if there is a exception , repeat the message and repeat the method again
            System.out.print(ex.toString());
            System.out.println("Please type a valid position.");
            read(player);
        }
    }
}

