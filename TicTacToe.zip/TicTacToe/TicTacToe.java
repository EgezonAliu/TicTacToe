public class TicTacToe {
     /** TIcTacTOe creates a TicTacToe game */
      /* @author Egzon Aliu */
    private Tabel tabel;
    private String actualPlayer = "";
    private String priorPlayer = "";
    private View view;
    
    private Input input;

    public TicTacToe() {
        tabel = new Tabel();
        input = new Input(tabel);
        view = new View(tabel);
        view.displayView();
       
    }
     public void startGame() throws TicTacToeException {
        boolean keepPlaying = true;
        actualPlayer = input.choosePlayer();
        while (keepPlaying) {
            do {
                input.read(actualPlayer);
                view.displayView();
                changePlayer();
            }
             while (tabel.stillToPlay(priorPlayer));
            view.displayResult(priorPlayer);
            keepPlaying = input.playAgain() ;
            if (keepPlaying) {
                tabel.clean();
                view.displayView();
                actualPlayer = input.choosePlayer();
            }
        }
    }
    private void changePlayer() {
      priorPlayer = actualPlayer ;
        if (actualPlayer.equals("X")) {
            actualPlayer = "O";
        } else {
          actualPlayer = "X";
        }
    }
}


