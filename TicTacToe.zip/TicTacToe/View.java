public class View {

    private Tabel tabel;

    public View(Tabel tabel) {
        this.tabel = tabel;
    }

    public void print(String s) {
        System.out.print(s);
    }

    public void printLn(String s) {
        System.out.println(s);
    }
    
 public void displayView() {
        for (int i = 0; i < Tabel.ROWS; i++) {
            for (int j = 0; j < Tabel.COLUMN; j++) {
                // if the box is empty display 3 spaces
                if (tabel.getBox(i, j).isEmpty()) {
                    print("   ");
                } else {
                    print(" " + tabel.getBox(i, j).getValue() + " ");
                }
                // if it is the last column  don't print it 
                if (j < Tabel.COLUMN - 1) {
                    print("|");
                }
            }
            System.out.println();
            if (i < Tabel.ROWS - 1) {
                printLn("-----------");
            }
        }
    }
     public void displayResult(String player) {
        if (tabel.winer(player)) {
            printLn("Winner is " + player );
        } else {
            printLn("There is no winner ");
        }
      printLn("=======================================");
    }
}


