public class TicTacToeException extends Exception{
	
	public TicTacToeException(String message){
		super(message);
	}
}