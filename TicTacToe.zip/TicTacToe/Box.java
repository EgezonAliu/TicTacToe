public class Box {

    private String value  = "";

    public void clean() {
        value = "";
    }
  public boolean isEmpty() {
        return value.equals("");
    }

    public String getValue() {
        return value ;
    }

public void setValue(String value) throws TicTacToeException {
        // if there is a value
        // It is not empty , throw a exception
        if (!isEmpty()) {
            throw new TicTacToeException("Box already has a value !!!");
        }
        this.value = value ;
    }
}
