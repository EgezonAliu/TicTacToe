public class Tabel {

    private Box[][] box ;

    public static final int ROWS = 3;
    public static final int COLUMN = 3;

    private int actualRow;
    private int actualColumn ;

    public Tabel() {
        box = new Box[ROWS][COLUMN];
        for (int row = 0; row < ROWS; row++) {
            for (int column = 0; column < COLUMN; column++) {
                box[row][column] = new Box();
            }
        }
    }
     public boolean gameFinished(String player) {
        return winer(player) || isDraw();
    }

    public boolean stillToPlay(String player) {
        return !gameFinished(player);
    }

 public boolean isDraw() {
        for (int row = 0; row < ROWS; row++) {
            for (int column = 0; column < COLUMN; column++) {
                if (box[row][column].isEmpty()) {
                    return false;
                }
            }
        }
        return true;
    }
public boolean winer(String value) {
        //  Check whether there are winners in the row. So the line is fixed while the columns being checked are 0.1.2    
            if (box[actualRow][0].getValue().equals(value)
                && box[actualRow][1].getValue().equals(value)
                && box[actualRow][2].getValue().equals(value)) {
            return true;
        }
        //  Check whether there are winners in the row , the column is fixed while the controlled rows are 0.1.2
                if (box[0][actualColumn].getValue().equals(value)
                && box[1][actualColumn].getValue().equals(value)
                && box[2][actualColumn].getValue().equals(value)) {
            return true;
        }
        



// if the actualRow and the actualColumn are equal, then position 0.0 or position 2.2
        // so it should be checked diagonally from left to right
        if (actualRow == actualColumn
                && box[0][0].getValue().equals(value)
                && box[1][1].getValue().equals(value)
                && box[2][2].getValue().equals(value)) {
            return true;
        }
        



// if the actualRow + actualColumn is 2, then it has the position or is the position 0,2 or position 2,0
        // so it should be checked diagonally from right to left
        if (actualRow + actualColumn == 2   // 3-in-the-opposite-diagonal
                && box[0][2].getValue().equals(value)
                && box[1][1].getValue().equals(value)
                && box[2][0].getValue().equals(value)) {
            return true;
        }
        return false;
    }
    
 public void clean() {
        for (int row = 0; row < ROWS; row++) {
            for (int column = 0; column < COLUMN; column++) {
                box[row][column].clean();
            }
        }
    }

    public void saveActualRowColumn(int row, int column) {
        actualRow = row ;
        actualColumn = column ;
    }

    public void setValue(int row, int column, String value) throws TicTacToeException {
        box[row][column].setValue(value);
    }

    public Box getBox(int i, int j) {
        return box[i][j];
    }
    
     public Box [][] getTabel() {
        return box;
    }
}
